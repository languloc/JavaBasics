package Ej_9;

public class ej_9 {
	
	public static void main(String[] args) {
		
		for (int i = 1950; i <= 2020; i++) {
		
			if (i%4==0) {
			System.out.println(i);
			}
		}
	}
}
